﻿using System.Windows.Forms;
namespace WindowPowerPoint
{
    class DoubleBufferedPanel : Panel
    {
        public DoubleBufferedPanel()
        {
            DoubleBuffered = true;
        }
    }
}
