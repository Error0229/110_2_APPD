﻿namespace WindowPowerPoint
{
    public interface ISlide
    {
        int SlideIndex 
        { 
            get; set; 
        }
    }
}
