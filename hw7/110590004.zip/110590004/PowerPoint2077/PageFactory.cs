﻿namespace WindowPowerPoint
{

    public class PageFactory
    {
        // get page
        public Page GetPage()
        {
            Page page = new Page();
            return page;
        }
    }
}
