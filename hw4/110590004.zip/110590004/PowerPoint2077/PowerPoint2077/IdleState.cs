using System;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;
namespace WindowPowerPoint
{
    public class IdleState : IState
    {
        // handle mouse down
        public void MouseDown(Point point)
        {

        }

        // handle mouse move
        public void MouseMove(Point point)
        {

        }

        // handle mouse up
        public void MouseUp(Point point)
        {

        }

        // handle Draw
        public void Draw(IGraphics graphics)
        {

        }

        // handle key down
        public void KeyDown(Keys keyCode)
        {

        }

    }
}
