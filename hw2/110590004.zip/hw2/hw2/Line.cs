﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowPowerPoint
{
    class Line : Shape
    {
        public Line()
        {
            _name = Constant.LINE_CHINESE;
        }
    }
}
