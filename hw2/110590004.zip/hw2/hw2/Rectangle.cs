﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowPowerPoint
{
    public class Rectangle : Shape
    {
        public Rectangle()
        {
            _name = Constant.RECTANGLE_CHINESE;
        }
    }
}
